"use strict";(globalThis.webpackChunk_affine_monorepo=globalThis.webpackChunk_affine_monorepo||[]).push([[5566],{90090:(e,n,t)=>{/**
 * @license React
 * use-sync-external-store-shim.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var o=t(70846),u="function"==typeof Object.is?Object.is:function(e,n){return e===n&&(0!==e||1/e==1/n)||e!=e&&n!=n},r=o.useState,i=o.useEffect,a=o.useLayoutEffect,c=o.useDebugValue;function s(e){var n=e.getSnapshot;e=e.value;try{var t=n();return!u(e,t)}catch(e){return!0}}var f="undefined"==typeof window||void 0===window.document||void 0===window.document.createElement?function(e,n){return n()}:function(e,n){var t=n(),o=r({inst:{value:t,getSnapshot:n}}),u=o[0].inst,f=o[1];return a(function(){u.value=t,u.getSnapshot=n,s(u)&&f({inst:u})},[e,t,n]),i(function(){return s(u)&&f({inst:u}),e(function(){s(u)&&f({inst:u})})},[e]),c(t),t};n.useSyncExternalStore=void 0!==o.useSyncExternalStore?o.useSyncExternalStore:f},88520:(e,n,t)=>{e.exports=t(90090)}}]);
//# sourceMappingURL=chunk.npm-async-use-sync-external-store.js.map