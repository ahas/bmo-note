(globalThis.webpackChunk_affine_monorepo=globalThis.webpackChunk_affine_monorepo||[]).push([[5343],{8356:(r,t)=>{var n;/*!
	Copyright (c) 2018 Jed Watson.
	Licensed under the MIT License (MIT), see
	http://jedwatson.github.io/classnames
*/!function(){"use strict";var o={}.hasOwnProperty;function e(){for(var r=[],t=0;t<arguments.length;t++){var n=arguments[t];if(n){var i=typeof n;if("string"===i||"number"===i)r.push(n);else if(Array.isArray(n)){if(n.length){var a=e.apply(null,n);a&&r.push(a)}}else if("object"===i){if(n.toString!==Object.prototype.toString&&!n.toString.toString().includes("[native code]")){r.push(n.toString());continue}for(var p in n)o.call(n,p)&&n[p]&&r.push(p)}}}return r.join(" ")}r.exports?(e.default=e,r.exports=e):void 0!==(n=(function(){return e}).apply(t,[]))&&(r.exports=n)}()}}]);
//# sourceMappingURL=chunk.npm-async-classnames.js.map