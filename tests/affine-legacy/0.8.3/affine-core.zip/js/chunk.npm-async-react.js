"use strict";(globalThis.webpackChunk_affine_monorepo=globalThis.webpackChunk_affine_monorepo||[]).push([[9917],{20774:(e,r,o)=>{/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var n=o(70846),t=Symbol.for("react.element"),_=Symbol.for("react.fragment"),f=Object.prototype.hasOwnProperty,a=n.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,l={key:!0,ref:!0,__self:!0,__source:!0};function p(e,r,o){var n,_={},p=null,s=null;for(n in void 0!==o&&(p=""+o),void 0!==r.key&&(p=""+r.key),void 0!==r.ref&&(s=r.ref),r)f.call(r,n)&&!l.hasOwnProperty(n)&&(_[n]=r[n]);if(e&&e.defaultProps)for(n in r=e.defaultProps)void 0===_[n]&&(_[n]=r[n]);return{$$typeof:t,type:e,key:p,ref:s,props:_,_owner:a.current}}r.Fragment=_,r.jsx=p,r.jsxs=p},2873:(e,r,o)=>{e.exports=o(20774)}}]);
//# sourceMappingURL=chunk.npm-async-react.js.map