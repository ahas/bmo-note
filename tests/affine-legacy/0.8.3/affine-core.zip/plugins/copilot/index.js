(({   imports: $h‍_imports,   liveVar: $h‍_live,   onceVar: $h‍_once,   importMeta: $h‍____meta,  }) => {   $h‍_imports([["react", []],["react-dom/client", []],["./index-82891f.mjs", []],["react/jsx-runtime", []],["@affine/component", []],["@toeverything/components/button", []],["jotai", []],["jotai/utils", []],["@affine/sdk/entry", []],["@blocksuite/icons", []]]);   
})
//# sourceURL=index.js
