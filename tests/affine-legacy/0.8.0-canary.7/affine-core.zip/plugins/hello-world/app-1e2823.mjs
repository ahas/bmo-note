({ imports: $h‍_imports, liveVar: $h‍_live, onceVar: $h‍_once, importMeta: $h‍____meta }) => {
  let jsx, Tooltip, IconButton, Logo1Icon, useCallback;
  $h‍_imports([["react/jsx-runtime", [["jsx", [($h‍_a) => jsx = $h‍_a]]]], ["@affine/component", [["Tooltip", [($h‍_a) => Tooltip = $h‍_a]], ["IconButton", [($h‍_a) => IconButton = $h‍_a]]]], ["@blocksuite/icons", [["Logo1Icon", [($h‍_a) => Logo1Icon = $h‍_a]]]], ["react", [["useCallback", [($h‍_a) => useCallback = $h‍_a]]]]]);
  const HeaderItem = () => {
    return /* @__PURE__ */ jsx(Tooltip, { content: "Plugin Enabled", children: /* @__PURE__ */ jsx(
      IconButton,
      {
        onClick: useCallback(() => {
          console.log("clicked hello world!");
        }, []),
        children: /* @__PURE__ */ jsx(Logo1Icon, {})
      }
    ) });
  };
  $h‍_once.HeaderItem(HeaderItem);
};
